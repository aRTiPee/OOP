/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package polralabexerpdf2;

/**
 *
 * @author artipee
 */
public class polRALabExer201 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int[] val = {0, 1, 2, 3};
        int sum = val[0]+val[1]+val[2]+val[3];
        System.out.println( "Sum of all numbers = " + sum );
    }
    
}
